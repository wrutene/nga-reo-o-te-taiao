NGĀ REO O TE TAIAO — TERM 3 WEBSITE PACKAGE

FILES
- index.html: student journal
- TEACHER_SETUP.html: setup and Classroom instructions

RECOMMENDED WORKFLOW
1. Host index.html on GitHub Pages or the school website.
2. Post the link in Google Classroom.
3. Students complete the journal on the same Chromebook/browser.
4. Students click Download Completed Journal and submit the downloaded HTML file.

LIMITATION
This version saves locally rather than to a teacher dashboard.
